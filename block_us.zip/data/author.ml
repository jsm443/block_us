let hours_worked = 80
